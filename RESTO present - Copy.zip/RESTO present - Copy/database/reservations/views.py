from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import Reservation

def reservation_view(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        contact_number = request.POST['contact_number']
        number_of_persons = request.POST['number_of_persons']
        date = request.POST['date']
        time = request.POST['time']
        
        reservation = Reservation.objects.create(
            name=name,
            email=email,
            contact_number=contact_number,
            number_of_persons=number_of_persons,
            date=date,
            time=time
        )
        
        if request.is_ajax():
            return JsonResponse({'status': 'success', 'reservation_id': reservation.id})
        
        return redirect('reservation_success', reservation_id=reservation.id)
    return render(request, 'reservations/reservation_form.html')

def reservation_success(request, reservation_id):
    reservation = Reservation.objects.get(id=reservation_id)
    return render(request, 'reservations/reservation_success.html', {'reservation': reservation})

def reservation_list(request):
    reservations = Reservation.objects.all()
    return render(request, 'reservations/reservation_list.html', {'reservations': reservations})